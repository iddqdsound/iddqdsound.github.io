-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(40178, 0)
  reaper.Main_OnCommand(40178, 0)
  reaper.Main_OnCommand(40178, 0)
  reaper.Main_OnCommand(40178, 0)
  reaper.Main_OnCommand(40178, 0)
  reaper.Main_OnCommand(40178, 0)
  reaper.Main_OnCommand(40178, 0)

  reaper.Undo_EndBlock('move note down a fifth', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()