-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(40010, 0)
  reaper.Main_OnCommand(40639, 0)
  reaper.Main_OnCommand(40011, 0)

  reaper.Undo_EndBlock('Duplicate Passage', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()