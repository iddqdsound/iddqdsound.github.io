-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(54164, 0)
  reaper.Main_OnCommand(54179, 0)
  reaper.Main_OnCommand(2008, 0)
  reaper.Main_OnCommand(40635, 0)
  reaper.Main_OnCommand(40331, 0)

  reaper.Undo_EndBlock('Create 3 envelope points', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()