-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(55049, 0)
  reaper.Main_OnCommand(55050, 0)
  reaper.Main_OnCommand(41142, 0)

  reaper.Undo_EndBlock('Show Envelope Lane For Last Touched Parameter (One click)', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()