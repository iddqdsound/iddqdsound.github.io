-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(58452, 0)
  reaper.Main_OnCommand(53820, 0)
  reaper.Main_OnCommand(58448, 0)
  reaper.Main_OnCommand(2008, 0)
  reaper.Main_OnCommand(53822, 0)
  reaper.Main_OnCommand(58448, 0)

  reaper.Undo_EndBlock('Show Track Lineage', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()