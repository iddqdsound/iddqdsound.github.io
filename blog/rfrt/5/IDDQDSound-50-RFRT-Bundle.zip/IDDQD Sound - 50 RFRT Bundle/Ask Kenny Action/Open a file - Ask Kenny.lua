-- Created with Lokasenna_Create action to open a file... .lua
os.execute('open "" "/Volumes/SSDQD/Utilties/REAPER - Portable Install A/Ask Kenny.htm"')