-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(55215, 0)
  reaper.Main_OnCommand(54037, 0)

  reaper.Undo_EndBlock('Add IR', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()