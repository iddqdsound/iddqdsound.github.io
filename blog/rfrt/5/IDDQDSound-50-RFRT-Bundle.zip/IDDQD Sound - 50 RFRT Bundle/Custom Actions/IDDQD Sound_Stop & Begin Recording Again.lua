-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(2010, 0)
  reaper.Main_OnCommand(1016, 0)
  reaper.Main_OnCommand(2010, 0)
  reaper.Main_OnCommand(1013, 0)

  reaper.Undo_EndBlock('Stop & Begin', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()