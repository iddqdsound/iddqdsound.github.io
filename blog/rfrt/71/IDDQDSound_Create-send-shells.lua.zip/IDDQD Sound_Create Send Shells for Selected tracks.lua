--[[
 * ReaScript Name: Create Send Shells for Selected tracks
 * Author: 
 * Version: 1.0
]]--

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(57887, 0)
  reaper.Main_OnCommand(55063, 0)
  reaper.Main_OnCommand(56665, 0)
  reaper.Main_OnCommand(55003, 0)
  reaper.Main_OnCommand(55002, 0)
  reaper.Main_OnCommand(58523, 0)

  reaper.Undo_EndBlock('Create Send Shells for Selected tracks', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()