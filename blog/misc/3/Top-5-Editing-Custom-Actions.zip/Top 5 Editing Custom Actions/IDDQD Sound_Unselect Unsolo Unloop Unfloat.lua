--[[
 * ReaScript Name: Unselect Unsolo Unloop Unfloat
 * Author: IDDQD Sound
 * Version: 1.0
]]--

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(40635, 0)
  reaper.Main_OnCommand(40340, 0)
  reaper.Main_OnCommand(40769, 0)
  reaper.Main_OnCommand(55022, 0)

  reaper.Undo_EndBlock('Unselect Unsolo Unloop Unfloat', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()