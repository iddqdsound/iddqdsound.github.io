--[[
 * ReaScript Name: Bring together and Crossfade
 * Author: IDDQD Sound
 * Version: 1.0
]]--

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(58887, 0)
  reaper.Main_OnCommand(53704, 0)

  reaper.Undo_EndBlock('Bring together and Crossfade', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()