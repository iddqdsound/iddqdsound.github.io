--[[
 * ReaScript Name: Reverse Item
 * Author: IDDQD Sound
 * Version: 1.0
]]--

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(40270, 0)
  reaper.Main_OnCommand(40131, 0)

  reaper.Undo_EndBlock('Reverse Item', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()