--[[
 * ReaScript Name: Audition Item
 * Author: IDDQD Sound
 * Version: 1.0
]]--

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(55023, 0)
  reaper.Main_OnCommand(40635, 0)
  reaper.Main_OnCommand(40340, 0)
  reaper.Main_OnCommand(53656, 0)
  reaper.Main_OnCommand(53749, 0)
  reaper.Main_OnCommand(7, 0)
  reaper.Main_OnCommand(40630, 0)
  reaper.Main_OnCommand(40638, 0)
  reaper.Main_OnCommand(1007, 0)

  reaper.Undo_EndBlock('Audition Item', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()