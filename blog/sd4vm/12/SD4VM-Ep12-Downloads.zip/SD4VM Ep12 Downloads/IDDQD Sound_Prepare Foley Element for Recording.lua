--[[
 * ReaScript Name: Prepare Foley Element for Recording
 * Author: 
 * Version: 1.0
]]--

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(40057, 0)
  reaper.Main_OnCommand(40943, 0)
  reaper.Main_OnCommand(42398, 0)
  reaper.Main_OnCommand(53812, 0)
  reaper.Main_OnCommand(41173, 0)
  reaper.Main_OnCommand(53680, 0)
  reaper.Main_OnCommand(40944, 0)
  reaper.Main_OnCommand(40421, 0)
  reaper.Main_OnCommand(41307, 0)
  reaper.Main_OnCommand(41173, 0)
  reaper.Main_OnCommand(2008, 0)
  reaper.Main_OnCommand(40943, 0)

  reaper.Undo_EndBlock('Prepare Foley Element for Recording', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()