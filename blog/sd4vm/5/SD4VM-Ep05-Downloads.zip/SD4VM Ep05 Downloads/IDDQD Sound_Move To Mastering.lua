-- This script was created by Lokasenna_Generate script from custom action.lua

local function main()
  reaper.PreventUIRefresh(1)
  reaper.Undo_BeginBlock()

  reaper.Main_OnCommand(59108, 0)
  reaper.Main_OnCommand(40719, 0)
  reaper.Main_OnCommand(40290, 0)
  reaper.Main_OnCommand(40060, 0)
  reaper.Main_OnCommand(40058, 0)
  reaper.Main_OnCommand(55818, 0)
  reaper.Main_OnCommand(40720, 0)
  reaper.Main_OnCommand(42230, 0)
  reaper.Main_OnCommand(40717, 0)
  reaper.Main_OnCommand(40635, 0)
  reaper.Main_OnCommand(58159, 0)
  reaper.Main_OnCommand(55818, 0)

  reaper.Undo_EndBlock('Move To Mastering', 0)
  reaper.PreventUIRefresh(-1)
  reaper.UpdateArrange()
  reaper.UpdateTimeline()
end

main()